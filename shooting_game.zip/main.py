
import pygame
import random
import os

# Initialize pygame
pygame.init()

# Screen settings
WIDTH, HEIGHT = 480, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Shooting Game")

# Load assets
ASSET_DIR = os.path.join(os.path.dirname(__file__), 'assets')
IMG_DIR = os.path.join(ASSET_DIR, 'images')
SND_DIR = os.path.join(ASSET_DIR, 'sounds')

player_img = pygame.image.load(os.path.join(IMG_DIR, "player.png"))
enemy_img = pygame.image.load(os.path.join(IMG_DIR, "enemy.png"))
bullet_img = pygame.image.load(os.path.join(IMG_DIR, "bullet.png"))
explosion_img = pygame.image.load(os.path.join(IMG_DIR, "explosion.png"))

shoot_sound = pygame.mixer.Sound(os.path.join(SND_DIR, "shoot.wav"))
explosion_sound = pygame.mixer.Sound(os.path.join(SND_DIR, "explosion.wav"))

clock = pygame.time.Clock()
FPS = 60

# Player class
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = player_img
        self.rect = self.image.get_rect()
        self.rect.centerx = WIDTH // 2
        self.rect.bottom = HEIGHT - 10
        self.speedx = 0

    def update(self):
        self.speedx = 0
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.speedx = -5
        if keys[pygame.K_RIGHT]:
            self.speedx = 5
        self.rect.x += self.speedx
        self.rect.x = max(0, min(WIDTH - self.rect.width, self.rect.x))

    def shoot(self):
        bullet = Bullet(self.rect.centerx, self.rect.top)
        all_sprites.add(bullet)
        bullets.add(bullet)
        shoot_sound.play()

# Enemy class
class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = enemy_img
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, WIDTH - self.rect.width)
        self.rect.y = random.randint(-100, -40)
        self.speedy = random.randint(2, 6)

    def update(self):
        self.rect.y += self.speedy
        if self.rect.top > HEIGHT:
            self.rect.x = random.randint(0, WIDTH - self.rect.width)
            self.rect.y = random.randint(-100, -40)
            self.speedy = random.randint(2, 6)

# Bullet class
class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = bullet_img
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.bottom = y
        self.speedy = -10

    def update(self):
        self.rect.y += self.speedy
        if self.rect.bottom < 0:
            self.kill()

# Explosion effect
def explosion(center):
    exp = pygame.sprite.Sprite()
    exp.image = explosion_img
    exp.rect = exp.image.get_rect()
    exp.rect.center = center
    screen.blit(exp.image, exp.rect)
    pygame.display.flip()
    explosion_sound.play()
    pygame.time.wait(100)

# Sprite groups
all_sprites = pygame.sprite.Group()
enemies = pygame.sprite.Group()
bullets = pygame.sprite.Group()

player = Player()
all_sprites.add(player)

for _ in range(6):
    enemy = Enemy()
    all_sprites.add(enemy)
    enemies.add(enemy)

# Game loop
running = True
while running:
    clock.tick(FPS)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Shoot
    keys = pygame.key.get_pressed()
    if keys[pygame.K_SPACE]:
        player.shoot()

    all_sprites.update()

    # Check for collisions
    hits = pygame.sprite.groupcollide(enemies, bullets, True, True)
    for hit in hits:
        explosion(hit.rect.center)
        enemy = Enemy()
        all_sprites.add(enemy)
        enemies.add(enemy)

    screen.fill((0, 0, 0))
    all_sprites.draw(screen)
    pygame.display.flip()

pygame.quit()
