# mybookrepo


Book Repository Project for SEN 208 COurse
Built with Spring Boot
