package com.example.mybookrepo.Service;

import com.example.mybookrepo.Model.BookModel;
import com.example.mybookrepo.Repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    public Page<BookModel> findPaginated(int page, int size, String sortField, String sortDirection, String searchTerm) {
        Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ?
                Sort.by(sortField).ascending() : Sort.by(sortField).descending();

        Pageable pageable = PageRequest.of(page - 1, size, sort);

        if (searchTerm != null && !searchTerm.isEmpty()) {
            return bookRepository.findByTitleContainingIgnoreCaseOrAuthorContainingIgnoreCase(
                    searchTerm, searchTerm, pageable);
        }

        return bookRepository.findAll(pageable);
    }

    public BookModel save(BookModel book) {
        return bookRepository.save(book);
    }

    public BookModel findById(Long id) {
        BookModel book = bookRepository.findById(id).orElse(null);
        if (book == null) {
            return new BookModel(); 
        }
        return book;
    }

    public void deleteById(Long id) {
        bookRepository.deleteById(id);
    }
}