package com.example.mybookrepo.Controller;

import com.example.mybookrepo.Model.BookModel;
import com.example.mybookrepo.Service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/books")
public class BookController {

    // Book listing and structure
    @Autowired
    private BookService bookService;

    @GetMapping
    public String listBooks(Model model,
                            @RequestParam(defaultValue = "1") int page,
                            @RequestParam(defaultValue = "10") int size,
                            @RequestParam(defaultValue = "title") String sort,
                            @RequestParam(defaultValue = "asc") String dir,
                            @RequestParam(required = false) String search) {

        Page<BookModel> bookPage = bookService.findPaginated(page, size, sort, dir, search);

        model.addAttribute("books", bookPage.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", bookPage.getTotalPages());
        model.addAttribute("totalItems", bookPage.getTotalElements());
        model.addAttribute("sortField", sort);
        model.addAttribute("sortDir", dir);
        model.addAttribute("reverseSortDir", dir.equals("asc") ? "desc" : "asc");
        model.addAttribute("searchTerm", search);

        return "books/list";
    }
    
    @GetMapping("/view/{id}")
    public String viewBook(@PathVariable Long id, Model model) {
        model.addAttribute("book", bookService.findById(id));
        return "books/view";
    }
    
    // Book Modification
    @GetMapping("/new")
    public String showCreateForm(Model model) {
        model.addAttribute("book", new BookModel());
        return "books/form";
    }

    @PostMapping
    public String saveBook(@Valid @ModelAttribute("book") BookModel book,
                           BindingResult result) {
        if (result.hasErrors()) {
            return "books/form";
        }
        bookService.save(book);
        return "redirect:/books";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        model.addAttribute("book", bookService.findById(id));
        return "books/form";
    }

    @GetMapping("/delete/{id}")
    public String deleteBook(@PathVariable Long id) {
        bookService.deleteById(id);
        return "redirect:/books";
    }
}