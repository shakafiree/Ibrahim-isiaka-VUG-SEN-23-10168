package com.example.mybookrepo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybookrepoApplicationTests {

	@Test
	void contextLoads() {
	}

}
